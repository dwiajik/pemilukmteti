<?php
class Calon extends Eloquent {
	protected $table = 'calon';
}
