<html>
    <body>
        <form id="authform" method="post" action="<?php echo asset('login'); ?>">
            <input type="password" name="authcode"/>
            <input type="submit" value="Submit"/>
        </form>
    </body>
</html>