<html>
    <body>
        <form method="post" action="voteCalon">
            <input type="submit" name="nomorCalon" value="1" />
            <input type="submit" name="nomorCalon" value="2" />
            <input type="submit" name="nomorCalon" value="3" />
        </form>
    </body>
</html>