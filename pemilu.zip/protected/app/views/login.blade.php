<html>
    <body>
        <form id="login" method="post" action="<?php echo asset('vote'); ?>">
            <input type="text" name="nim"/>
            <input type="password" name="password"/>
            <input type="submit" value="Submit"/>
        </form>
    </body>
</html>